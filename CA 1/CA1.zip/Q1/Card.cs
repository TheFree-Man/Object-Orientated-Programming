﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Q1
{
    public class Card
    {
        public string Rank { get; set; }
        public string suit { get; set; }

    }
}
